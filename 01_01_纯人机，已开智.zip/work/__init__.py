"""Contest delivery package root."""
